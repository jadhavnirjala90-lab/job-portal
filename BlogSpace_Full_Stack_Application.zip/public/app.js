const $ = id => document.getElementById(id);
let currentUser = null, editingId = null, authMode = "register", allPublicBlogs = [];
$("year").textContent = new Date().getFullYear();

async function api(url, options = {}) {
  const response = await fetch(url, { credentials: "same-origin", ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Something went wrong.");
  return data;
}
function showAuth(mode) {
  authMode = mode; $("authSection").classList.remove("hidden");
  $("authTitle").textContent = mode === "register" ? "Create your account" : "Welcome back";
  $("authSubtitle").textContent = mode === "register" ? "Join the community and share your ideas." : "Log in to continue to your stories.";
  $("nameLabel").classList.toggle("hidden", mode !== "register");
  $("nameInput").classList.toggle("hidden", mode !== "register");
  $("nameInput").required = mode === "register";
  $("authSubmit").textContent = mode === "register" ? "Create account" : "Log in";
  $("switchAuth").firstChild.textContent = mode === "register" ? "Already have an account? " : "New to BlogSpace? ";
  $("switchButton").textContent = mode === "register" ? "Log in" : "Create account";
  $("authMessage").textContent = "";
}
function closeAuth(){ $("authSection").classList.add("hidden"); }
$("loginNav").onclick = () => showAuth("login");
$("signupNav").onclick = () => showAuth("register");
$("heroWrite").onclick = () => currentUser ? openEditor() : showAuth("register");
$("closeAuth").onclick = closeAuth;
$("switchButton").onclick = () => showAuth(authMode === "register" ? "login" : "register");
$("authForm").onsubmit = async e => {
  e.preventDefault(); $("authMessage").textContent = "Please wait...";
  try {
    const body = { email: $("emailInput").value, password: $("passwordInput").value };
    if (authMode === "register") body.name = $("nameInput").value;
    const data = await api(`/api/auth/${authMode}`, { method: "POST", body: JSON.stringify(body) });
    currentUser = data.user; closeAuth(); updateNav(); await loadDashboard();
  } catch(err) { $("authMessage").textContent = err.message; }
};
function updateNav(){
  ["loginNav","signupNav"].forEach(id => $(id).classList.toggle("hidden", !!currentUser));
  ["dashboardNav","logoutNav"].forEach(id => $(id).classList.toggle("hidden", !currentUser));
}
$("dashboardNav").onclick = () => { $("dashboard").classList.remove("hidden"); $("dashboard").scrollIntoView({behavior:"smooth"}); };
$("logoutNav").onclick = async () => { try { await api("/api/auth/logout",{method:"POST"}); } catch {} currentUser=null; updateNav(); $("dashboard").classList.add("hidden"); await loadPublicBlogs(); };
async function loadPublicBlogs(){
  try { const data=await api("/api/blogs"); allPublicBlogs=data.blogs; renderPublic(allPublicBlogs); }
  catch { $("publicBlogs").innerHTML='<div class="empty">Could not load stories. Please refresh.</div>'; }
}
function escapeHTML(value=""){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function excerpt(text){return text.length>150?text.slice(0,150)+"…":text;}
function renderPublic(blogs){
  $("publicBlogs").innerHTML=blogs.length?blogs.map(b=>`<article class="blog-card"><span class="category">${escapeHTML(b.category||"General")}</span><h3>${escapeHTML(b.title)}</h3><p>${escapeHTML(excerpt(b.content))}</p><div class="blog-meta"><span>By ${escapeHTML(b.user?.name||"Writer")}</span><span>${new Date(b.createdAt).toLocaleDateString()}</span></div></article>`).join(""):'<div class="empty">No stories yet. Be the first to write one!</div>';
}
$("searchInput").oninput=e=>{const q=e.target.value.toLowerCase();renderPublic(allPublicBlogs.filter(b=>(b.title+" "+b.category+" "+b.content+" "+(b.user?.name||"")).toLowerCase().includes(q)));};
async function loadDashboard(){
  $("dashboard").classList.remove("hidden"); $("dashboard").scrollIntoView({behavior:"smooth"});
  $("welcomeTitle").textContent=`Welcome, ${currentUser.name}`;
  $("profileName").textContent=currentUser.name; $("profileEmail").textContent=currentUser.email;
  try { const data=await api("/api/my-blogs"); renderMine(data.blogs); } catch(err){ $("myBlogs").innerHTML=`<div class="empty">${escapeHTML(err.message)}</div>`; }
}
function renderMine(blogs){
  $("myBlogs").innerHTML=blogs.length?blogs.map(b=>`<article class="blog-card"><span class="category">${escapeHTML(b.category||"General")}</span><h3>${escapeHTML(b.title)}</h3><p>${escapeHTML(excerpt(b.content))}</p><div class="blog-meta"><span>${new Date(b.createdAt).toLocaleDateString()}</span><span>Your story</span></div><div class="card-actions"><button class="btn btn-light" data-edit="${b._id}">Edit</button><button class="btn btn-light" data-delete="${b._id}">Delete</button></div></article>`).join(""):'<div class="empty">You have not published any blogs yet.</div>';
  document.querySelectorAll("[data-edit]").forEach(btn=>btn.onclick=()=>editBlog(btn.dataset.edit,blogs));
  document.querySelectorAll("[data-delete]").forEach(btn=>btn.onclick=()=>deleteBlog(btn.dataset.delete));
}
function openEditor(blog=null){
  if(!currentUser){showAuth("login");return;}
  editingId=blog?blog._id:null; $("editorTitle").textContent=blog?"Edit your blog":"Create a new blog";
  $("blogTitle").value=blog?.title||""; $("blogCategory").value=blog?.category||""; $("blogContent").value=blog?.content||"";
  $("blogMessage").textContent=""; $("blogFormWrap").classList.remove("hidden"); $("blogFormWrap").scrollIntoView({behavior:"smooth"});
}
$("newBlog").onclick=()=>openEditor();
$("cancelBlog").onclick=()=>{$("blogFormWrap").classList.add("hidden");editingId=null;};
$("blogForm").onsubmit=async e=>{
  e.preventDefault();const body={title:$("blogTitle").value,category:$("blogCategory").value,content:$("blogContent").value};
  try{await api(editingId?`/api/blogs/${editingId}`:"/api/blogs",{method:editingId?"PUT":"POST",body:JSON.stringify(body)});$("blogFormWrap").classList.add("hidden");editingId=null;await loadDashboard();await loadPublicBlogs();}
  catch(err){$("blogMessage").textContent=err.message;}
};
function editBlog(id,blogs){const blog=blogs.find(b=>b._id===id);if(blog)openEditor(blog);}
async function deleteBlog(id){if(!confirm("Delete this blog permanently?"))return;try{await api(`/api/blogs/${id}`,{method:"DELETE"});await loadDashboard();await loadPublicBlogs();}catch(err){alert(err.message);}}
$("editProfile").onclick=async()=>{const name=prompt("Enter your display name:",currentUser.name);if(name===null)return;try{const data=await api("/api/auth/profile",{method:"PATCH",body:JSON.stringify({name})});currentUser.name=data.user.name;await loadDashboard();}catch(err){alert(err.message);}};
async function init(){
  try{const data=await api("/api/auth/me");currentUser=data.user;updateNav();await loadDashboard();}catch{currentUser=null;updateNav();}
  await loadPublicBlogs();
}
init();