# BlogSpace — Full Stack Blog Application

A responsive full-stack blogging platform built with HTML, CSS, JavaScript, Node.js, Express and MongoDB.

## Features
- Register and log in with password hashing (bcrypt).
- JWT authentication stored in an HttpOnly cookie.
- Protected dashboard and profile update.
- Create, read, edit and delete your own blog posts.
- Public blog feed with search.
- Server-side ownership checks for edit/delete operations.
- Responsive layout for mobile, tablet and desktop.
- Basic security headers and authentication rate limiting.

## Tech stack
- Frontend: HTML5, CSS3, Vanilla JavaScript
- Backend: Node.js, Express.js
- Database: MongoDB with Mongoose
- Authentication: JWT + bcryptjs + HttpOnly cookies

## Requirements
- Node.js 18 or newer
- npm
- MongoDB Atlas account or a local MongoDB server

## Run locally
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
5. Add your MongoDB connection string to `MONGODB_URI`.
6. Set `JWT_SECRET` to a long, random secret (at least 32 characters).
7. Start the application:
   ```bash
   npm start
   ```
8. Open `http://localhost:3000`.

## Environment variables
| Variable | Description |
|---|---|
| `PORT` | Server port; hosting platforms usually provide this |
| `MONGODB_URI` | MongoDB connection string |
| `JWT_SECRET` | Long random secret used to sign session tokens |
| `NODE_ENV` | Set to `production` when deployed |

Never commit `.env` or share your database password/JWT secret.

## Deploy on Render
1. Push this project to a GitHub repository.
2. Sign in to Render and choose **New → Web Service**.
3. Connect the GitHub repository.
4. Set **Build Command** to `npm install`.
5. Set **Start Command** to `npm start`.
6. Add environment variables `MONGODB_URI`, `JWT_SECRET`, and `NODE_ENV=production`.
7. Deploy. Render provides the public URL after the build succeeds.

Use MongoDB Atlas for the database. In Atlas, create a database user and allow network access from your hosting service according to Atlas guidance. Do not put credentials in frontend files.

## GitHub upload
1. Sign in to GitHub and choose **New repository**.
2. Name it `blogspace-full-stack`.
3. Keep it public only if your internship requires a public repository; otherwise choose private.
4. Upload the extracted project files, or use Git:
   ```bash
   git init
   git add .
   git commit -m "Initial full stack blog application"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/blogspace-full-stack.git
   git push -u origin main
   ```
5. Confirm `.env` is not uploaded. The `.gitignore` file excludes it.

## LinkedIn project description
**BlogSpace — Full Stack Blog Application**

Developed a responsive full-stack blogging platform using HTML, CSS, JavaScript, Node.js, Express.js and MongoDB. Implemented user registration and login, JWT-based authentication using HttpOnly cookies, protected dashboards, profile updates, and CRUD operations for blog posts. Added a searchable public blog feed and responsive UI for mobile and desktop. Project includes setup documentation and deployment configuration.

GitHub: [Add your repository URL]
Live Demo: [Add your deployed URL]

## Important notes
- Configure MongoDB and environment variables before running or deploying.
- Test registration, login, logout, profile update and blog CRUD before submission.
- This is an internship/demo starter. Before production use, add automated tests, CSRF protection appropriate to your deployment, email verification, password reset, monitoring and backups.
