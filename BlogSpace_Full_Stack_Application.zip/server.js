require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === "production";

if (!process.env.MONGODB_URI || !process.env.JWT_SECRET) {
  console.error("Missing MONGODB_URI or JWT_SECRET in environment variables.");
  process.exit(1);
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false });

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 60 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, select: false }
}, { timestamps: true });

const blogSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 120 },
  category: { type: String, trim: true, maxlength: 40, default: "General" },
  content: { type: String, required: true, trim: true, maxlength: 10000 }
}, { timestamps: true });

const User = mongoose.model("User", userSchema);
const Blog = mongoose.model("Blog", blogSchema);

function makeToken(user) {
  return jwt.sign({ id: user._id.toString() }, process.env.JWT_SECRET, { expiresIn: "7d" });
}
function setAuthCookie(res, token) {
  res.cookie("token", token, {
    httpOnly: true, secure: isProduction, sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000, path: "/"
  });
}
function auth(req, res, next) {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ message: "Please log in." });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch {
    res.clearCookie("token", { httpOnly: true, secure: isProduction, sameSite: "lax", path: "/" });
    return res.status(401).json({ message: "Session expired. Please log in again." });
  }
}

app.post("/api/auth/register", authLimiter, async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: "Please fill in all fields." });
    if (String(name).trim().length < 2) return res.status(400).json({ message: "Name must contain at least 2 characters." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ message: "Enter a valid email address." });
    if (String(password).length < 8) return res.status(400).json({ message: "Password must be at least 8 characters." });
    if (await User.findOne({ email: String(email).toLowerCase().trim() })) return res.status(409).json({ message: "An account with this email already exists." });
    const hashed = await bcrypt.hash(password, 12);
    const user = await User.create({ name, email, password: hashed });
    setAuthCookie(res, makeToken(user));
    res.status(201).json({ user: { id: user._id, name: user.name, email: user.email } });
  } catch (err) { res.status(500).json({ message: "Could not create account." }); }
});

app.post("/api/auth/login", authLimiter, async (req, res) => {
  try {
    const email = String(req.body.email || "").toLowerCase().trim();
    const password = String(req.body.password || "");
    const user = await User.findOne({ email }).select("+password");
    if (!user || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ message: "Incorrect email or password." });
    setAuthCookie(res, makeToken(user));
    res.json({ user: { id: user._id, name: user.name, email: user.email } });
  } catch { res.status(500).json({ message: "Login failed. Please try again." }); }
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("token", { httpOnly: true, secure: isProduction, sameSite: "lax", path: "/" });
  res.json({ message: "Logged out successfully." });
});

app.get("/api/auth/me", auth, async (req, res) => {
  const user = await User.findById(req.userId).select("name email");
  if (!user) return res.status(401).json({ message: "User not found." });
  res.json({ user });
});

app.patch("/api/auth/profile", auth, async (req, res) => {
  const name = String(req.body.name || "").trim();
  if (name.length < 2 || name.length > 60) return res.status(400).json({ message: "Name must be between 2 and 60 characters." });
  const user = await User.findByIdAndUpdate(req.userId, { name }, { new: true }).select("name email");
  res.json({ user });
});

app.get("/api/blogs", async (req, res) => {
  const blogs = await Blog.find().populate("user", "name").sort({ createdAt: -1 }).limit(50);
  res.json({ blogs });
});

app.get("/api/my-blogs", auth, async (req, res) => {
  const blogs = await Blog.find({ user: req.userId }).sort({ createdAt: -1 });
  res.json({ blogs });
});

app.post("/api/blogs", auth, async (req, res) => {
  const { title, category, content } = req.body;
  if (!title || !content) return res.status(400).json({ message: "Title and content are required." });
  if (String(title).trim().length > 120 || String(content).trim().length > 10000) return res.status(400).json({ message: "Your blog is too long." });
  const blog = await Blog.create({ user: req.userId, title, category: category || "General", content });
  res.status(201).json({ blog });
});

app.put("/api/blogs/:id", auth, async (req, res) => {
  const { title, category, content } = req.body;
  if (!title || !content) return res.status(400).json({ message: "Title and content are required." });
  const blog = await Blog.findOneAndUpdate(
    { _id: req.params.id, user: req.userId },
    { title, category: category || "General", content },
    { new: true, runValidators: true }
  );
  if (!blog) return res.status(404).json({ message: "Blog not found or you do not have permission." });
  res.json({ blog });
});

app.delete("/api/blogs/:id", auth, async (req, res) => {
  const blog = await Blog.findOneAndDelete({ _id: req.params.id, user: req.userId });
  if (!blog) return res.status(404).json({ message: "Blog not found or you do not have permission." });
  res.json({ message: "Blog deleted." });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

mongoose.connect(process.env.MONGODB_URI)
  .then(() => app.listen(PORT, () => console.log(`Blog app running on port ${PORT}`)))
  .catch(err => { console.error("Database connection failed:", err.message); process.exit(1); });
